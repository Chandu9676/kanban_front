import "./userStyles.css";
import { useState, useEffect } from "react";
import { useHistory } from "react-router-dom";
import ReactToExcel from "react-html-table-to-excel";
const axios = require("axios").default;

export default function ViewProjects({ match }) {
  const userId = match.params.id;

  // const [access, viewProjectsAccess] = useState(false);

  const [projectList, setProjects] = useState([]);
  const [deleteProject, setdeleteProject] = useState(null);

  console.log(userId);
  console.log(projectList);
  let history = useHistory();

  useEffect(() => {
    axios
      .get("http://localhost:8080/api/kanban_board/getprojectdetails", {
        params: {
          userId: userId,
        },
      })
      .then((response) => {
        if (response.data.projectList == null) {
          alert("): No active projects :(");
        } else {
          setProjects(response.data.projectList);
        }
      });

    if (deleteProject !== null) {
      axios
        .delete("http://localhost:8080/api/kanban_board/deleteproject", {
          params: {
            projectId: deleteProject.projectId,
          },
        })
        .then((response) => {
          // if (response.data.projectEntity == null) {
          //   alert("): No active projects :(");
          // }
        });
    }
  }, [userId, deleteProject]);

  return (
    <body class="">
      <div class="container">
        <div class="card">
          <div class="card-body">
            <h5 class="card-tittle">Projects Details</h5>

            <table
              class="table table-striped table-hover table-bordered"
              id="table-to-excel"
            >
              <thead>
                <tr>
                  <th scope="col">Project Id</th>
                  <th scope="col">Project Name</th>
                  <th scope="col">Password</th>
                  <th scope="col">Start Date</th>
                  <th scope="col">End date</th>
                  <th scope="col">Status</th>

                  <th class="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {projectList.map((project) => (
                  <tr key={project.id}>
                    <td>{project.projectId}</td>
                    <td>{project.projectName}</td>
                    <td>{project.projectPassword}</td>
                    <td>{project.startDate}</td>
                    <td>{project.endDate}</td>
                    <td>{project.projectStatus}</td>
                    <td class="text-right">
                      <button
                        class="btn btn-success badge-pill"
                        onClick={() => {
                          history.push(`/manageProject/${project.projectId}`);
                        }}
                      >
                        Manage
                      </button>
                      &nbsp;
                      <button
                        class="btn btn-danger badge-pill"
                        onClick={() => {
                          setdeleteProject(project);
                        }}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <ReactToExcel
              className="btn btn-success"
              table="table-to-excel"
              filename="excelfile"
              sheet="sheet 1"
              buttonText="download"
            />
           
          </div>
        </div>
       
      </div>

      {/* <div class="container ">
        <div class="row proejct-card table-view-point">
         
          <div class="col-md-10 table-padding">
            <div class="table-wrapper">
              <div class="table-tittle">
                <div class="row">
                  <div class="col-sm-4">
                    <h5 class="text-left">List of Projects</h5>
                  </div>
                  <div class="col-md-4"></div>
                </div>
                <table class="table table-stripped table-hover">
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Project Name</th>
                      <th>Description</th>
                      <th>Actions</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr data-status="active">
                      <td>24</td>
                      <td>Varma</td>
                      <td>45654534</td>
                      <td>
                        
                          <button type="button" class="btn btn-success">
                            Delete
                          </button>
                          </td>
                          <td>
                        
                        <button type="button" class="btn btn-success">
                          Manage
                        </button>
                        </td>
                         
                     
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div> */}
    </body>
  );
}

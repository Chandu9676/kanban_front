import "./userStyles2.css";
import { useState, useEffect } from "react";
import { useHistory } from "react-router-dom";
import { GrMail } from "react-icons/gr";
import { MdDelete } from "react-icons/md";
import Mail from "./mail";
const axios = require("axios").default;

export default function ViewTeamLeader({ match }) {
  const [teamLead, setTeamLeadList] = useState([]);
  const [teamLeadDelete, setTeamLeadDelete] = useState(null);
  const [notification, setNotification] = useState(null);
  const [mailInfo, setMailInfo] = useState({});

  const id = match.params.projectId;

  useEffect(() => {
    axios
      .get("http://localhost:8080/api/kanban_board/getlead", {
        params: {
          projectId: id,
        },
      })
      .then((response) => {
        if (response.data.teamLeadList.length !== null) {
          setTeamLeadList(response.data.teamLeadList);
        } else {
          alert("No Active Records Found");
        }
      });

    if (teamLeadDelete !== null) {
      axios
        .delete("http://localhost:8080/api/kanban_board/deleteteamlead", {
          params: {
            teamLeaderId: teamLeadDelete.teamLeaderId,
          },
        })
        .then((response) => {
          //
          // if (response.data) {
          //   alert("Are you sure You want to delete : Click again to delete..");
          // }
        });
    }
  }, [id, teamLeadDelete]);

  if (notification) {
    return <Mail teamLead={mailInfo} />;
  }

  console.log(teamLead);

  return (
    <body class="">
      <div class="container margin-top-view">
        <div class="card">
          <div class="card-body">
            {/* <h4 class="card-tittle-1"><FaUserAlt /></h4> */}
            <h5 class="card-tittle-1">Team Lead Details</h5>

            <table class="table table-striped table-hover table-bordered">
              <thead>
                <tr>
                  <th scope="col">Id</th>
                  <th scope="col">Team Lead Name</th>
                  <th scope="col">Employee Id</th>
                  <th scope="col">Password</th>

                  <th class="text-center">Actions</th>
                </tr>
              </thead>

              <tbody>
                {teamLead.map((lead) => (
                  <tr key={lead.id}>
                    <td>{lead.teamLeaderId}</td>
                    <td>{lead.teamLeaderName}</td>
                    <td>{lead.employeeId}</td>
                    <td>{lead.projectPassword}</td>

                    <td class="text-center">
                      <MdDelete
                        onClick={() => {
                          setTeamLeadDelete(lead);
                        }}
                      />
                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <GrMail
                        onClick={() => {
                          setNotification(true);
                          setMailInfo(lead);
                        }}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div
        class="modal fade"
        id="exampleModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">
                New message
              </h5>
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body">
              <form>
                <div class="mb-3">
                  <label for="recipient-name" class="col-form-label">
                    Recipient:
                  </label>
                  <input type="text" class="form-control" id="recipient-name" />
                </div>
                <div class="mb-3">
                  <label for="message-text" class="col-form-label">
                    Message:
                  </label>
                  <textarea class="form-control" id="message-text"></textarea>
                </div>
              </form>
            </div>
            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Close
              </button>
              <button type="button" class="btn btn-primary">
                Send message
              </button>
            </div>
          </div>
        </div>
      </div>
    </body>
  );
}

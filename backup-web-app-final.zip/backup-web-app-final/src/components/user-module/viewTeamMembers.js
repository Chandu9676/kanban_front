import "./userStyles2.css";
import { useState, useEffect } from "react";
import { useHistory } from "react-router-dom";
import { FaUsers } from "react-icons/fa";
import { MdDelete } from "react-icons/md";
import { GrMail } from "react-icons/gr";
import Mail from "./mail";
const axios = require("axios").default;

export default function ViewTeamMembers({ match }) {
  const [teamMembers, setTeamMembersList] = useState([]);
  const [deleteTeamMember, setdeleteTeamMember] = useState(null);
  const [notification, setNotification] = useState(null);
  const [mailInfo, setMailInfo] = useState({});

  const projectId = match.params.projectId;

  useEffect(() => {
    axios
      .get(
        "http://localhost:8080/api/kanban_board/getmembers",

        {
          params: {
            projectId: projectId,
          },
        }
      )
      .then((response) => {
        if (response.data.membersList.length == 0) {
          alert("No Active Records Found..");
        } else {
          setTeamMembersList(response.data.membersList);
        }
      });

    if (deleteTeamMember !== null) {
      axios
        .delete("http://localhost:8080/api/kanban_board/deleteteammember", {
          params: {
            teamMemberId: deleteTeamMember.teamMemberId,
          },
        })
        .then((response) => {});
    }
  }, [projectId, deleteTeamMember]);

  console.log(teamMembers);
  console.log(deleteTeamMember);

  if (notification) {
    return <Mail teamMember={mailInfo} />;
  }

  return (
    <body class="">
      <div class="container margin-top-view">
        <div class="card">
          <div class="card-body">
            <h3 class="card-tittle-1">
              <FaUsers />{" "}
            </h3>
            <h5 class="card-tittle-1"> Team Members Details</h5>
            <table class="table table-striped table-hover table-bordered">
              <thead>
                <tr>
                  <th scope="col">Team member Id</th>
                  <th scope="col">Team member Name</th>
                  <th scope="col">Employee Id</th>
                  <th scope="col">Password</th>

                  <th class="text-center">Actions</th>
                </tr>
              </thead>
              <tbody>
                {teamMembers.map((member) => (
                  <tr key={member.id}>
                    <td>{member.teamMemberId}</td>
                    <td>{member.teamMemberName}</td>
                    <td>{member.employeeId}</td>
                    <td>{member.projectPassword} </td>
                    <td class="text-center">
                      <MdDelete
                        onClick={() => {
                          setdeleteTeamMember(member);
                        }}
                      />
                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <GrMail
                        onClick={() => {
                          setNotification(true);
                          setMailInfo(member);
                        }}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </body>
  );
}

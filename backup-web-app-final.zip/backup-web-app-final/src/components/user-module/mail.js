import "./side.css";
import { useHistory } from "react-router-dom";
import { useState } from "react";
const axios = require("axios").default;

export default function Mail(props) {
  let history = useHistory();
  function handleClick() {
    history.push("/viewProjects");
  }

  const setDetails = {
    name: "",
    empId: "",
    emailId: "",
    body: "",
    subject: "",
    projectName: "",
    projectPassword: "",
  };

  const [mailDetails, setMailDetails] = useState(setDetails);

  const mail = {
    name: "",
    empId: "",
    emailId: mailDetails.emailId,
    subject: "",
    body: mailDetails.body,
   
    projectName: "",
    projectPassword: "",
  };
  //   mail.name = "chandu"
  console.log(mail);

  const handleInput1 = (e) => {
    var { name, value } = e.target;
    setMailDetails({
      ...mailDetails,
      [name]: value,
    });
  };
  const handleInput2 = (e) => {
    var { name, value } = e.target;
    setMailDetails({
      ...mailDetails,
      [name]: value,
    });
  };

  if (props.teamLead) {
    const lead = props.teamLead;
    console.log(lead);

    mail.name = lead.teamLeaderName;
    mail.empId = lead.employeeId;
    mail.projectName = lead.projectEntity.projectName;
    mail.projectPassword = lead.projectEntity.projectPassword;
  } else {
    const member = props.teamMember;
    console.log(member);
    mail.name = member.teamMemberName;
    mail.empId = member.employeeId;
    mail.projectName = member.projectEntity.projectName;
    mail.projectPassword = member.projectEntity.projectPassword;
  }

  const handleSubmit = (e) => {
    e.preventDefault();

    axios
    .post("http://localhost:8080/api/kanban_board/mail", mail)
    .then((response) => {
      if (response.data) {
        alert("Message sent successfully");
        
      } else {
        alert("Sending failed :server not responding please try again");
      }
    });
  };

  return (
    <div class="row">
      <div class="col-md-4"></div>
      <div class="col-md-6 text-color-mail-form">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">
            New message
          </h5>
        </div>
        <div class="modal-body">
          <form onSubmit={handleSubmit}>
            <div class="mb-3">
              <label for="recipient-name" class="col-form-label">
                Recipient:
              </label>
              <input
                type="email"
                class="form-control"
                id="recipient-name"
                placeholder="Enter valid email id"
                name="emailId"
                // pattern="[A-Za-z\s]{4,20}"
                // title="Only alphabets allowed  range between 4-20 characters"
                required
                onChange={handleInput1}
              />
            </div>
            <div class="mb-3">
              <label for="message-text" class="col-form-label">
                Message:
              </label>
              <textarea
                class="form-control"
                id="message-text"
                placeholder="Enter text"
                name="body"
                // pattern="[A-Za-z\s]{4,20}"
                // title="Only alphabets allowed  range between 4-20 characters"
                required
                onChange={handleInput2}
                F
              ></textarea>
            </div>

            <div class="modal-footer text-center">
              <button type="submit" class="btn btn-success">
                Send message
              </button>
              <button
                type="button"
                class="btn btn-secondary"
                data-bs-dismiss="modal"
                onClick={handleClick}
              >
                Close
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

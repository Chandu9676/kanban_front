
import {useState, useEffect} from 'react';
const axios = require("axios").default;

export default function Profile({ match }) {

    const [state, setstate] = useState({});
    const userId = match.params.id;


    useEffect(() => {
        axios
          .get("http://localhost:8080/api/kanban_board/getuser", {
            params: {
              userId:   userId,
            },
          })
          .then((response) => {
            setstate(response.data.userEntity);
          
          });
        }, [userId]);


  return (
    <div class="body">
      <div className="container card-view">
        <div className="row">
          <div className="card col-md-6 offset-md-3 offset-md-3">
            <h3 className="text-left mt-4">User Profile</h3>
            <div className="card-body">
              <form>
                <div className="form-group">
                  <label>
                    User Id
                  </label>
                  <input
                    placeholder={state.userId}
                    name="assessmentTimeDuration"
                    className="form-control"
                    disabled
                  />
                </div>
                <div className="form-group">
                  <label>Name</label>
                  <input
                    placeholder={state.userName}
                    name="assessmentName"
                    className="form-control"
                    disabled

                  />
                </div>
                <div className="form-group">
                  <label>Email Id</label>
                  <input
                    placeholder={state.emailId}
                    name="assessmentType"
                    className="form-control"
                    disabled

                  />
                </div>
                <div className="form-group">
                  <label>
                    Password
                    {/* <FontAwesomeIcon icon={faCalendarAlt} /> */}
                  </label>
                  <input
                    placeholder={state.password}
                    name="assessmentReleaseDate"
                    className="form-control"
                    disabled

                  />
                </div>

                <div className="form-group">
                  <label>
                    Organization
                    {/* <FontAwesomeIcon icon={faClock}/>  */}
                  </label>
                  <input
                    placeholder={state.organisation}
                    name="assessmentTimeDuration"
                    className="form-control"
                    disabled

                  />
                </div>

                {/* <button
                  className="btn btn-success"
                  //  onClick={this.cancel.bind(this)}
                  style={{ marginLeft: "10px" }}
                >
                  Cancel
                </button> */}
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

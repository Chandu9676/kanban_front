import "./side.css";
import ViewProjects from "./viewProjects";
import { Component } from "react";
import {
  BrowserRouter as Router,
  Route,
  useHistory,
  Switch,
  Link,
} from "react-router-dom";
import { FaUserCircle,FaFileDownload } from "react-icons/fa";
import { MdAccountBox, MdList,MdPortrait,MdLibraryAdd ,MdViewHeadline} from "react-icons/md";
import ManageProject from "./manageProject";
import Home from "./home";
import AddProject from "./AddProject";
import Profile from "./userProfile";

export default class SideBar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      user: this.props.user,
      id: this.props.user.userId,
    };
  }

  render() {
    return (
      <Router>
        <body>
          <script src="https://kit.fontawesome.com/b99e675b6e.js"></script>

          <div class="wrapper">
            <div class="sidebar">
              <ul>
              <li>
                <Link class="nav-link" to="/">
                     Home
                  </Link>
                </li>
                <li>
                  <Link class="nav-link" to={`/profile/${this.state.id}`}>
                  <MdAccountBox /> &nbsp;Profile
                  </Link>
                </li>
               
                
                <li>
                  <Link class="nav-link" to={`/viewProjects/${this.state.id}`}>
                    <MdViewHeadline />&nbsp; View projects
                  </Link>
                </li>
              
                <li>
                  <Link class="nav-link" to={`/addproject/${this.state.id}`}>
                    <MdLibraryAdd />&nbsp;
                    Add project
                  </Link>
                </li>
                
              </ul>
             
            </div>
            <div class="main_content">
              {/* <div class="header">Welcome!! Have a nice day.</div> */}
              
                <Route
                  exact
                  path="/viewProjects/:id"
                  component={ViewProjects}
                ></Route>

                <Route
                  exact
                  path="/manageProject/:projectId"
                  component={ManageProject}
                ></Route>
                {/* <Route exact path="/" component={Home}></Route> */}
                <Route
                  exact
                  path="/addProject/:id"
                  component={AddProject}
                ></Route>

                <Route
                  exact
                  path="/profile/:id"
                  component={Profile}
                ></Route>
              </div>
            </div>
          
          <div class="side-bar-content"> 
          chandu           
          </div>
        </body>
      </Router>
    );
  }
}

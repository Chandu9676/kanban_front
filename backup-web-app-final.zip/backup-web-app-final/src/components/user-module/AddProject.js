import React, { Component } from "react";
//import Project  from '../actions/ProjectService';
import "./side.css";
import ProjectService from "../../services/ProjectService";
import { FcKindle,FcAddRow,FcAddColumn} from "react-icons/fc";

class AddProject extends Component {
  constructor(props) {
    super(props);
    this.state = {
      projectId: "",
      projectName: "",
      startDate: "",
      endDate: "",
      projectDescription: "",
      projectStatus: "",
      projectPassword: "",
      userId: props.id,
    };
     console.log(this.state.userId);

    this.changeProjectNameHandler = this.changeProjectNameHandler.bind(this);
    this.changeStartDateHandler = this.changeStartDateHandler.bind(this);
    this.changeEndDateHandler = this.changeEndDateHandler.bind(this);
    this.changeProjectDescriptionHandler = this.changeProjectDescriptionHandler.bind(
      this
    );
    this.changeProjectStatusHandler = this.changeProjectStatusHandler.bind(
      this
    );
    this.changeUserIdHandler = this.changeUserIdHandler.bind(this);
    this.changeProjectPasswordHandler = this.changeProjectPasswordHandler.bind(
      this
    );
    this.saveProject = this.saveProject.bind(this);
  }

  saveProject = (e) => {
    e.preventDefault();

    let project = {
      projectId: null,
      projectName: this.state.projectName,
      projectDescription: this.state.projectDescription,
      startDate: this.state.startDate,
      endDate: this.state.endDate,
      projectStatus: this.state.projectStatus,
      projectPassword: this.state.projectPassword,
      userEntity: { userId: this.state.userId },
    };
    console.log(JSON.stringify(project));
    console.log(project);
    ProjectService.createProject(project).then((res) => {
      if (res.data.message === "Project Added") {
        alert("New project created");
        // this.props.history.push("/");
      }
    });
  };

  cancel() {
    this.props.history.push("/");
  }

  changeProjectNameHandler = (event) => {
    this.setState({ projectName: event.target.value });
  };

  changeStartDateHandler = (event) => {
    this.setState({ startDate: event.target.value });
  };

  changeEndDateHandler = (event) => {
    this.setState({ endDate: event.target.value });
  };
  changeProjectDescriptionHandler = (event) => {
    this.setState({ projectDescription: event.target.value });
  };

  changeProjectStatusHandler = (event) => {
    this.setState({ projectStatus: event.target.value });
  };
  changeProjectPasswordHandler = (event) => {
    this.setState({ projectPassword: event.target.value });
  };
  changeUserIdHandler = (event) => {
    this.setState({ userId: event.target.value });
  };

  render() {
    return (
      <div>
        <div className="container card-view">
          <div className="row">
            <div className="card col-md-6 offset-md-3 offset-md-3">
              <h3 className="text-left mt-4" ><FcAddColumn />Create Project</h3>
              <div className="card-body">
                <form onSubmit={this.saveProject}>
                  <div className="form-group text-center">
                
                    <input
                      placeholder="Enter Project Name"
                      name="assessmentName"
                      class="form-control"
                      pattern="[A-Za-z0-9\s]{4,30}"
                      title="Only alphabets allowed range between 4-30 characters"
                      required
                      value={this.state.projectName}
                      onChange={this.changeProjectNameHandler}
                      
                      
                    />
                  </div>
                  <div className="form-group text-center">
                    
                    <input
                      placeholder="Enter Satrt Date"
                      name="assessmentType"
                      type="date"
                      class="form-control"

                      required
                      value={this.state.startDate}
                      onChange={this.changeStartDateHandler}
                     
                    />
                  </div>
                  <div className="form-group text-center">
                    
                    <input
                      placeholder="Enter End Date"
                      name="assessmentReleaseDate"
                      type="date"
                      class="form-control"
                      required
                      value={this.state.endDate}
                      onChange={this.changeEndDateHandler}
                    />
                  </div>

                  <div className="form-group text-center">
                  
                    <input
                      placeholder="Enter Project Description"
                      name="assessmentTimeDuration"
                      class="form-control"
                      pattern="[A-Za-z0-9'\.\-\s\,]{1,100}"
                      title="Range between 1 to 100 "
                      required
                      value={this.state.projectDescription}
                      onChange={this.changeProjectDescriptionHandler}
                    />
                  </div>
                  <div className="form-group text-center">
                   
                    <input
                      placeholder=" Enter Project status"
                      name="assessmentTimeDuration"
                      class="form-control"
                      pattern="[A-Za-z0-9'\.\-\s\,]{1,100}"
                      title="Range between 1 to 100 "
                      required
                      value={this.state.projectStatus}
                      onChange={this.changeProjectStatusHandler}
                    />
                  </div>
                  <div className="form-group text-center">
                  
                    <input
                      placeholder="Enter Project password"
                      name="assessmentTimeDuration"
                      class="form-control"
                      pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}"
                      title="Password must contain atleast 6 characters, atleast one UPPER LOWER case and numbers"
                      required
                      value={this.state.projectPassword}
                      onChange={this.changeProjectPasswordHandler}
                    />
                  </div>
                  <div className="form-group text-center">
                    
                    <input
                      placeholder=" Enter UserId"
                      name="assessmentTimeDuration"
                      class="form-control"
                      pattern="[1-9]{1}[0-9]{0,100}"
                      title="Only numbers allowed for this field"
                      required
                      value={this.userId}
                      onChange={this.changeUserIdHandler}
                    />
                  </div>
                  <div className="form-group text-center">
                  <button
                    className="btn btn-success float-center"
                    
                  >
                    Save
                  </button>
                  <button
                    className="btn btn-danger"
                    onClick={this.cancel.bind(this)}
                    style={{ marginLeft: "10px" }}
                  >
                    Cancel
                  </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default AddProject;

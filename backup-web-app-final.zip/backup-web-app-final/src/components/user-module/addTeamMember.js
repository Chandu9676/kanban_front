import { useState, useEffect } from "react";
import "./side.css";
const axios = require("axios").default;

export default function AddTeamMember({ match }) {
  const [project, setproject] = useState({});
  const projectId = match.params.projectId;
  console.log(projectId);
  console.log(project);

  const addTeamMember = {
    projectEntity: {
      projectId: project.projectId,
      projectPassword: project.projectPassword,
    },
    teamMemberName: "",
    employeeId: "",
  };

  const [addMember, setaddTeamMember] = useState(addTeamMember);

  const details = {
    teamMemberName: addMember.teamMemberName,
    employeeId: addMember.employeeId,
    projectEntity: {
      projectId: project.projectId,
      projectPassword: project.projectPassword,
    },
  };
  console.log(details);

  const handleInput1 = (e) => {
    var { name, value } = e.target;
    setaddTeamMember({
      ...addMember,
      [name]: value,
    });
  };
  const handleInput2 = (e) => {
    var { name, value } = e.target;
    setaddTeamMember({
      ...addMember,
      [name]: value,
    });
  };
  const handleSubmit = (e) => {
    e.preventDefault();

    axios
      .post("http://localhost:8080/api/kanban_board/addteammember", details)
      .then((response) => {
        if (response.data.message !== null ) {
          alert("Team Member Added successfully");
        } else {
          alert("Something went wrong : Fail to Add");
        }
      });
  };

  useEffect(() => {
    axios
      .get("http://localhost:8080/api/kanban_board/getproject", {
        params: {
          projectId: projectId,
        },
      })
      .then((response) => {
        setproject(response.data.projectEntity);
      });
  }, [projectId]);

  return (
    <div class="row">
      <div class="col-md-3"></div>
      <div class="col-md-6 padding-top-add">
        <form onSubmit={handleSubmit}>
          <h5 class="text-left header-color">Add Team Member </h5>
          <h4 class="border-bottom border-color"></h4>
          <div class="form-group col-md-12">
            <input
              type="text"
              class="form-control"
              placeholder="Enter Name"
              name="teamMemberName"
              onChange={handleInput1}
              pattern="[A-Za-z\s]{4,20}"
              title="Only alphabets allowed  range between 4-20 characters"
              required
            ></input>
          </div>
          <div class="form-group col-md-12 login-field">
            <input
              type="text"
              class="form-control"
              placeholder="Employee Id"
              name="employeeId"
              onChange={handleInput2}
              pattern="^[1-9]{1}[0-9]{0,100}"
              title="Only numbers allowed "
              required
            ></input>
          </div>

          <div class="form-group col-md-12 login-field">
            <button
              type="submit"
              class="btn btn-success form-control signup-button"
            >
              Submit
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
